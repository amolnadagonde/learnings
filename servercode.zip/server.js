// import express from 'express';
const express = require('express');
const bodyParser = require('body-parser');
const routes = require("./routes/routes.js");

const port = 3131;

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// routes(app);

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get('/', (req, res)=>{
  res.send("Hello world from server..!")
})

app.post('/login', function(request, result, next){
  console.log('request body: ', request.body);
  let validUser = request.body.username == 'admin' && request.body.password == '123';
  result.send({
    validUser
  });
})

app.listen(port, function(){
  console.log("Server is running on "+port+" port.")
});