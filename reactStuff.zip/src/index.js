import React from "react";
import ReactDOM from "react-dom";

import axios from 'axios';

class Index extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      username: '',
      password: '',
    }

    this.formSubmit = this.formSubmit.bind(this);
    this.onInputChange = this.onInputChange.bind(this);
  }

  componentDidMount(){
    axios.get(`http://localhost:3131/`)
      .then(response => {
        // console.log('response:', response);
        this.setState({
          welcomeText: response.data
        })
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  }

  onInputChange(event){
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  formSubmit(e){
    e.preventDefault();

    axios({
      method: 'post',
      url: 'http://localhost:3131/login',
      data: {
        username: this.state.username,
        password: this.state.password
      }
    })
    .then(response => {
      console.log('response:', response.data.validUser);
    });
  }

  render(){
    return(
      <div>
        <form onSubmit={this.formSubmit}>
          Username:<input type="text" name="username" value={this.state.username} onChange={this.onInputChange} />
          Password:<input type="password" name="password" value={this.state.password} onChange={this.onInputChange} />
          <input type="submit" value="Submit" />
        </form>
      </div>
    )
  }
}

ReactDOM.render(<Index />, document.getElementById("index"));